GUIDE

Name your homework in this way:

homework1.java
homework2.java
...


Your java file should include the problem in commented section / java doc section
Your solution should be inside a class and inside a method
Your java class should contain a MAIN method which can run basic test of your solution