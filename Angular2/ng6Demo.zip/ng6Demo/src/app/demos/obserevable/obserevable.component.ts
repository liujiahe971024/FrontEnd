import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-obserevable',
  templateUrl: './obserevable.component.html',
  styleUrls: ['./obserevable.component.css']
})
export class ObserevableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
