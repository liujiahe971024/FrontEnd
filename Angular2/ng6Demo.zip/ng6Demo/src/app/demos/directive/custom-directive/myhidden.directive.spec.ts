import { MyhiddenDirective } from './myhidden.directive';

describe('MyhiddenDirective', () => {
  it('should create an instance', () => {
    const directive = new MyhiddenDirective();
    expect(directive).toBeTruthy();
  });
});
