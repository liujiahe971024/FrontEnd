import { MyifDirective } from './myif.directive';

describe('MyifDirective', () => {
  it('should create an instance', () => {
    const directive = new MyifDirective();
    expect(directive).toBeTruthy();
  });
});
