package com.company.edms.model;

import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;

import javax.persistence.*;
import java.sql.Date;
import java.util.Objects;

@Entity
@Table(name = "employee")
public class Employee {

    @Id
    @Column(name = "empid")
    private int id;

    private String name;

    @Column(name = "hiredate")
    private Date hireDate;

    private String job;

    @Column(name = "manager")
    private Integer managerId;

    private double salary;

    @Column(name = "deptid")
    private Integer departmentId;

    //foreigh key
    /*@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "deptid")
    private Department department;*/

    public Employee(int id, String name, Date hireDate, String job, int managerId, double salary, int departmentId) {
        this.id = id;
        this.name = name;
        this.hireDate = hireDate;
        this.job = job;
        this.managerId = managerId;
        this.salary = salary;
        this.departmentId = departmentId;
    }

    public Employee(int id) {
        this.id = id;
    }

    public Employee(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public Employee(){}

    public Employee(int id, String name, String job, double salary) {
        this.id = id;
        this.name = name;
        this.job = job;
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    public void setId(int empId) {
        this.id = empId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getHireDate() {
        return hireDate;
    }

    public void setHireDate(Date hireDate) {
        this.hireDate = hireDate;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public Integer getManagerId() {
        return managerId;
    }

    public void setManagerId(Integer managerId) {
        this.managerId = managerId;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

/*    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }*/

    public Integer getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Integer departmentId) {
        this.departmentId = departmentId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Employee employee = (Employee) o;
        return id == employee.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Employee{" +
                "empId=" + id +
                ", name='" + name + '\'' +
                ", hireDate=" + hireDate +
                ", job='" + job + '\'' +
                ", managerId=" + managerId +
                ", salary=" + salary +
                ", department=" + departmentId +
                '}';
    }
}
