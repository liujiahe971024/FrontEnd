package com.company.edms.controller;

import com.company.edms.model.Employee;
import com.company.edms.model.EmployeeDTO;
import com.company.edms.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Set;

@Controller
@RequestMapping("/employee")
public class EmployeeController {

    @Autowired
    EmployeeService service;

    @GetMapping(value = "/{id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable int id){
        Employee e = service.getEmployee(id);
        return new ResponseEntity<Employee>(e, HttpStatus.OK); //200
    }

    @RequestMapping(value = "/all", method = RequestMethod.GET)
    public @ResponseBody Set<Employee> getEmployees(){
        Set<Employee> employees = service.getEmployees();
        return employees;
    }

    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    public ResponseEntity<Void> updateEmployee(@RequestBody Employee employee) /*throws Exception*/{
        try {
            service.updateEmployee(employee);
        } catch (Exception e) {
           return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<Void>(HttpStatus.OK);
    }


    @PostMapping("/create")
    public ResponseEntity<Void> createEmployee(@RequestBody Employee employee){
        service.createEmployee(employee);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public @ResponseBody void deleteEmployee(@PathVariable("id") int deletedId){
        service.deleteEmployee(deletedId);
    }


    @GetMapping("/everything")
    public @ResponseBody List<EmployeeDTO> getEmployeeWithDepartment(){
        return service.getEmployeeWithDepartment();
    }
}
