package com.company.edms.util;

import com.company.edms.dao.DepartmentDAO;
import com.company.edms.model.Department;
import com.company.edms.repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class DepartmentHelper {

   DepartmentRepository repository;

    public DepartmentRepository getRepository() {
        return repository;
    }

    @Autowired
    public void setRepository(DepartmentRepository repository) {
        this.repository = repository;
    }

    public Department getDepartment(int id) {
        return repository.findById(id).get();
    }

    public Department getDepartment(String name) {
        return repository.findByName(name);
    }

    public List<Department> getDepartmentsByLocation(String loc) {
        return repository.findAllByLocation(loc);
    }

    public List<Department> findAllDepartments() {
        return repository.findAll();
    }
}
