package com.company.edms.util;


import com.company.edms.dao.EmployeeDAO;
import com.company.edms.model.Department;
import com.company.edms.model.Employee;
import com.company.edms.model.EmployeeDTO;
import com.company.edms.repository.DepartmentRepository;
import com.company.edms.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Component
public class EmployeeHelper {

    //EmployeeDAO dao;
    EmployeeRepository repo;

    @Autowired
    DepartmentRepository departmentRepository;

    @Autowired
    public EmployeeHelper(EmployeeRepository repo){
        this.repo = repo;
    }

    public Employee getEmployee(int id) {
        return repo.findById(id).get();
    }

    public Set<Employee> getEmployees() {
        Set<Employee> result = new HashSet<>();
        for(Employee e : repo.findAll()){
            result.add(e);
        }
        return result;
    }

    public void updateEmployee(Employee employee) throws Exception {
        boolean exist = repo.existsById(employee.getId());
        Employee existingEmployee = this.getEmployee(employee.getId());
        if(existingEmployee == null){
            throw new Exception("Employee does not exist");
        }
        existingEmployee.setName(employee.getName());
        existingEmployee.setJob(employee.getJob());
        existingEmployee.setSalary(employee.getSalary());
        repo.save(existingEmployee);
    }

    public void updateEmployee2(Employee employee) throws Exception {
        boolean exist = repo.existsById(employee.getId());
        if(!exist){
            throw new Exception("Employee does not exist");
        }
        repo.save(employee);
    }

    public void createEmployee(Employee newEmp) {
        List<Employee> employees = repo.findAll();
        int maxId = employees.stream().map(e -> e.getId()).mapToInt(o -> o).max().orElse(0);
        newEmp.setId(maxId + 1);
        repo.save(newEmp);
    }

    public void deleteEmployee(int deletedId) {
        repo.deleteById(deletedId);
    }

    public List<EmployeeDTO> getEmployeeWithDepartment() {
        Set<Employee> employees = this.getEmployees();
        List<Department> departments = departmentRepository.findAll();

        List<EmployeeDTO> result = new ArrayList<>();
        for(Employee e: employees){
            EmployeeDTO dto = new EmployeeDTO();
            dto.setId(e.getId());
            dto.setHireDate(e.getHireDate());
            dto.setJob(e.getJob());
            dto.setManagerId(e.getManagerId());
            dto.setName(e.getName());
            dto.setSalary(e.getSalary());

            Department temp = departments.stream().filter(d -> d.getId() == e.getDepartmentId()).findFirst().orElse(null);
            dto.setDepartment(temp);

            result.add(dto);
        }

        return result;
    }
}
