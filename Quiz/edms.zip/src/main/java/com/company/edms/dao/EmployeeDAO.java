package com.company.edms.dao;

import com.company.edms.model.Employee;
import org.springframework.stereotype.Repository;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

@Repository
public class EmployeeDAO {

    private static final Set<Employee> employees = new HashSet<>();

    static{
        employees.add(new Employee(1, "Alice", "Boss", 100000.00));
        employees.add(new Employee(2, "Bob", "Manager", 80000.00));
        employees.add(new Employee(3, "Cathy", "Anaylst", 60000.00));
        employees.add(new Employee(4, "Daniel", "Programmer", 4000.00));
    }


    public Employee getEmployee(int id){
        return employees.stream().filter(e -> e.getId() == id).findFirst().orElse(null);
    }

    public Set<Employee> getAllEmployees(){
        return employees;
    }

    public void addEmployee(Employee newEmp){
        int maxId = employees.stream().map(e -> e.getId()).mapToInt(o -> o).max().orElse(0);
        newEmp.setId(maxId + 1);
        employees.add(newEmp);
    }

    public void updateEmployee(Employee updateEmp) throws Exception{
        //Employee existingEmployee = employees.stream().filter(e -> e.getId() == updateEmp.getId()).findAny().orElse(null);
        Employee existingEmployee = getEmployee(updateEmp.getId());
        if(existingEmployee == null){
            throw new Exception("Employee does not exist");
        }
        existingEmployee.setName(updateEmp.getName());
        existingEmployee.setJob(updateEmp.getJob());
        existingEmployee.setSalary(updateEmp.getSalary());
    }


    public void deleteEmployee(int id){
        Iterator<Employee> iterator = employees.iterator();
        while(iterator.hasNext()){
            Employee temp = iterator.next();
            if(temp.getId() == id){
                iterator.remove();
            }
        }
    }

    public void deleteEmployees(){
        employees.clear();
       // employees = new HashSet<>();
    }

}
