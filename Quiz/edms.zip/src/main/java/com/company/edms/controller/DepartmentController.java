package com.company.edms.controller;

import com.company.edms.model.Department;
import com.company.edms.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/department")
public class DepartmentController {

    @Autowired
    DepartmentService service;

    @GetMapping("/id/{id}")
    public Department getDepartmentById(@PathVariable int id){
        return service.getDepartment(id);
    }

    @GetMapping("/name/{name}")
    public Department getDepartmentByName(@PathVariable String name){
        return service.getDepartment(name);
    }

    @GetMapping("/loc/{loc}")
    public List<Department> getDepartmentsByLocation(@PathVariable String loc){
        return service.getDepartmentsByLocation(loc);
    }

    @GetMapping("/get")
    public List<Department> getDepartmentByInput(
            @RequestParam(value = "id", required = false) Integer id,
            @RequestParam(value = "name", required = false) String name,
            @RequestParam(value = "loc", required = false) String location
    ){
        if(id != null){
            return new ArrayList<>(Arrays.asList(service.getDepartment(id)));
        }
        if(name != null && name.trim() != null && name.length() != 0){
            return new ArrayList<>(Arrays.asList(service.getDepartment(name)));
        }
        if(location != null && location.trim() != null && location.length() != 0){
            return service.getDepartmentsByLocation(location);
        }
        return null;
    }
}
