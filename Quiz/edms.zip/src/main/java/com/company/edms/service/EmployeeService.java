package com.company.edms.service;

import com.company.edms.dao.EmployeeDAO;
import com.company.edms.model.Employee;
import com.company.edms.util.EmployeeHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
public class EmployeeService {

    @Autowired
    EmployeeHelper helper;

    public Employee getEmployee(int id) {
        return helper.getEmployee(id);
    }

    public Set<Employee> getEmployees() {
        return helper.getEmployees();
    }

    public void updateEmployee(Employee employee) throws Exception {
        helper.updateEmployee(employee);
    }

    public void createEmployee(Employee employee) {
        helper.createEmployee(employee);
    }

    public void deleteEmployee(int deletedId) {
        helper.deleteEmployee(deletedId);
    }
}
