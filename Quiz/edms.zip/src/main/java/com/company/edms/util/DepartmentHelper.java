package com.company.edms.util;

import com.company.edms.dao.DepartmentDAO;
import com.company.edms.model.Department;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class DepartmentHelper {

    DepartmentDAO dao;

    public DepartmentDAO getDao() {
        return dao;
    }

    @Autowired
    public void setDao(DepartmentDAO dao) {
        this.dao = dao;
    }

    public Department getDepartment(int id) {
        return dao.getDepartment(id);
    }

    public Department getDepartment(String name) {
        return dao.getDepartment(name);
    }

    public List<Department> getDepartmentsByLocation(String loc) {
        return dao.getDepartmentByLocation(loc);
    }
}
