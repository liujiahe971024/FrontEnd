package com.company.edms.dao;

import com.company.edms.model.Department;
import com.company.edms.model.Employee;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Repository
public class DepartmentDAO {

    private static final List<Department> departments = new ArrayList<>();

    static{
        departments.add(new Department(10, "ACCOUNTING", "NEW YORK"));
        departments.add(new Department(20, "RESEARCH", "DALLAS"));
        departments.add(new Department(30, "SALES", "CHICAGO"));
        departments.add(new Department(40, "OPERATIONS", "BOSTON"));
        departments.add(new Department(50, "OUTSOURCE", "DALLAS"));
    }

    public Department getDepartment(int id){
        return departments.stream().filter(d -> id == d.getId()).findFirst().orElse(null);
    }

    public Department getDepartment(String name){
        return departments.stream().filter(d -> name.equalsIgnoreCase(d.getName())).findFirst().orElse(null);
    }

    public List<Department> getDepartmentByLocation(String loc){
        return departments.stream().filter(d -> loc.equalsIgnoreCase(d.getLocation())).collect(Collectors.toList());
    }

    public List<Department> getDepartments(){
        return departments;
    }
}
