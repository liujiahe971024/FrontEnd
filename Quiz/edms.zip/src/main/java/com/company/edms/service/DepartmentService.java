package com.company.edms.service;

import com.company.edms.dao.DepartmentDAO;
import com.company.edms.model.Department;
import com.company.edms.util.DepartmentHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentService {

    @Autowired
    DepartmentHelper helper;

    public Department getDepartment(int id) {
       return helper.getDepartment(id);
    }

    public Department getDepartment(String name) {
        return helper.getDepartment(name);
    }

    public List<Department> getDepartmentsByLocation(String loc) {
        return helper.getDepartmentsByLocation(loc);
    }
}
