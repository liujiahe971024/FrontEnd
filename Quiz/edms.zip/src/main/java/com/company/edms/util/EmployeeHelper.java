package com.company.edms.util;


import com.company.edms.dao.EmployeeDAO;
import com.company.edms.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Set;

@Component
public class EmployeeHelper {

    EmployeeDAO dao;

    @Autowired
    public EmployeeHelper(EmployeeDAO dao){
        this.dao = dao;
    }

    public Employee getEmployee(int id) {
        return dao.getEmployee(id);
    }

    public Set<Employee> getEmployees() {
        return dao.getAllEmployees();
    }

    public void updateEmployee(Employee employee) throws Exception {
        dao.updateEmployee(employee);
    }

    public void createEmployee(Employee employee) {
        dao.addEmployee(employee);
    }

    public void deleteEmployee(int deletedId) {
        dao.deleteEmployee(deletedId);
    }
}
